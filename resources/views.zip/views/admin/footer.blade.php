<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        Developed by <a href="#">Roger</a>
    </div>
    <!-- Default to the left -->
    <strong>Copyright © 2018 <a href="#">Zurich Industries</a>.</strong> All rights reserved.
</footer>