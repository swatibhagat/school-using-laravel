<?php namespace App\Http\Controllers\admin;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Session;
use \Input as Input;
class TimeTableController extends Controller {

	public function __construct(){
	}
	
	/**
	 * @Dashboard
	 */
	public function index(){ 
		if(!Session::get('adid'))
		{		 		    
		   return redirect('admin/login')->withErrors(['Please login']); 		    		 
		}			
		return view("admin.home");
	}
	
	public function create_time_table()
	{
		if(!Session::get('adid')) {		 		    
		   return redirect('admin/login')->withErrors(['Please login']); 		    		 
		}	
		$academic = $this->getAlldata("zurich_academic","Y"); 
		$course = $this->getAlldata("zurich_course","Y"); 
		$batch = $this->getAlldata("zurich_batch","Y");
		$emp = $this->getAlldata("zurich_employee_regt","Y");
		$suject = $this->getAlldata("zurich_subject","Y");
		$suj_emp = $this->getAlldata("zurich_subject_allocation","Y");
		return view("admin.create_time_table",["suject"=>$suject,"emp"=>$emp,"suj_emp"=>$suj_emp,"academic"=>$academic,"course"=>$course,"batch"=>$batch,"i"=>1]);
	}
	
	public function select_section_for_allocation($id)
	{
		//echo $id;
		$batch = $this->getrow("zurich_batch","course_id",$id);
		if($batch!=""){
			echo '<option value="">Select Section</option>';
			foreach($batch as $dep){
				echo '<option value="'.$dep->batch_id.'">'.$dep->batch_name.'</option>';
			}
		}
							
	}
	public function select_subject($str)
	{
		//echo $str;
		$nstr=explode("---",$str);
		$sub=["course"=>$nstr[0],"batch"=>$nstr[1],"academic"=>$nstr[2]];
		$suject = $this->getrowconditions("zurich_subject_allocation",$sub);
		
		if(empty($suject)){
			echo "Not Found";
		}else{
			echo '<option value="">Select Subject</option>';
			foreach($suject as $co)
			{
				$s_name = $this->getrow("zurich_subject","id",$co->subject);
				foreach($s_name as $sn)
				echo '<option value="'.$co->subject.'">'.$sn->sub_name.'</option>';
				
			}
		}
		
	}
	public function select_teacher($str)
	{
		//echo $str;
		$nstr=explode("---",$str);
		$teacher=["course"=>$nstr[0],"batch"=>$nstr[1],"academic"=>$nstr[2]];
		$emp = $this->getrowconditions("zurich_subject_allocation",$teacher);
		
		if(empty($emp)){
			echo "Not Found";
		}else{
			echo '<option value="">Select Teacher</option>';
			foreach($emp as $co)
			{
				$e_name = $this->getrow("zurich_employee_regt","emp_id",$co->emp_name);
				foreach($e_name as $en)
				echo '<option value="'.$co->emp_name.'">'.$en->emp_fname.' '.$en->emp_mid_name.' '.$en->emp_lname.'</option>';
				
			}
		}
		
	}
	
	public function insert_time_table(Request $request) {
		if(!Session::get('adid')) {		 		    
		   return redirect('admin/login')->withErrors(['Please login']); 	    		 
		}
			$academic=$request->input('academic');
			$course=$request->input('course');
			$batch=$request->input('batch');
			$subject=$request->input('subject');
			$teacher=$request->input('teacher');
			
			$select_data=["acadamic_id"=>$academic,
			"course_id"=>$course,
			"batch_id"=>$batch,
			"subject_id"=>$subject,
			"teacher_id"=>$teacher
			];
			
			$e_name = $this->getrowconditions("zurich_time_table",$select_data);
			if(!empty($e_name)){
				return redirect('create_time_table')->withErrors(['Record already exist...']);
			}else{
				$data = [
				"acadamic_id"=>$academic,
				"course_id"=>$course,
				"batch_id"=>$batch,
				"subject_id"=>$subject,
				"teacher_id"=>$request->input('teacher'),
				"d1"=>$request->input('mon'),
				"d2"=>$request->input('tue'),
				"d3"=>$request->input('wed'),
				"d4"=>$request->input('thus'),
				"d5"=>$request->input('fri'),
				"d6"=>$request->input('sat'),
				"d7"=>$request->input('sun'),
				"date"=>date('Y-m-d'),
				"status"=>1			
				];
				$result = $this->save("zurich_time_table",$data);
				if(count($result) > 0) {
					 return redirect('create_time_table')->with('message', 'Added successfully...');				 	
				} else {
					return redirect('create_time_table')->withErrors(['Some error occurred']);
				}
			}
			
	}
	
	
/*
| Common functions 
|
*/
	public function getAlldata($table,$flag) {
	    $results =  DB::table($table)->get();		
		if($flag=="Y"){
			if(count($results) > 0) {
			  $result = $results;	
			} else {
			  $result = '';
			}
		} else {
			$result  = $results[0];			 
		}
		return $result;
	}
	public function getAlldataDesc($table,$col,$flag) {
	    $results =  DB::table($table)->orderBy($col, 'desc')->get();		
		if($flag=="Y"){
			if(count($results) > 0) {
			  $result = $results;	
			} else {
			  $result = '';
			}
		} else {
			$result  = $results[0];			 
		}
		return $result;
	}
	
	
	public function getrow($table,$mid,$id) {
		//$rows = DB::select('select * from '.$table.' where '.$mid.' = ?',[$id]);
            //->update($data);
			$rows = DB::table($table) 
            ->where($mid, $id)
            ->get();
	    return $rows;
	}
	
	public function getrowdouble($table,$col1,$val1,$col2,$val2) {
		
			$rows = DB::table($table) 
            ->where($col1, $val1)
            ->where($col2, $val2)
            ->get();
	    return $rows;
	}
	public function getrowtriple($table,$col1,$val1,$col2,$val2,$col3,$val3) {
		
			$rows = DB::table($table) 
            ->where($col1, $val1)
            ->where($col2, $val2)
            ->where($col3, $val3)
            ->get();
	    return $rows;
	}
	public function getrowconditions($table,$data) {
		$rows = DB::table($table) 
            ->where($data)
            ->get();
	    return $rows;
	}
	public function updateRecords($table,$id,$value,$data) {
		$result = DB::table($table) 
            ->where($id, $value)
            ->update($data);
	    return $result;
	}

	public function save($table,$data) {
		$id = DB::table($table)->insertGetId($data);
	    return $id;
	}	
	
	public function delete_data($table,$col,$id){
		$del = DB::table($table)
		->where($col,$id)
		->delete();
		return $del;
	}

}
